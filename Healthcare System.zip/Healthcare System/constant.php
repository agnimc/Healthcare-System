<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>C Array</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<link rel="stylesheet" type="text/css"  href="css/file1.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
 
<script type="text/javascript" src="css/run_prettify.js"></script>
</head>

<body  data-spy="scroll" data-target=".navbar" data-offset="50">


<?php
include 'header.php';

?>


<div class="col-sm-8" style="border:1px solid #c3c3c3; background:#FFFF;" >

<span style="color:white";><h2 align="center" style="background-color:#3399FF";>C Array</h2></span>

<hr/>
<div><ul class="pager">
<li class="previous">
<a href="inline-functions.php">&larr; Prev</a>
</li>
<li class="next">
<a href="constructors-and-destructors-in-cpp.php">Next &rarr;</a>
</li>
</ul></div>

<h4 class="h44" align="center">Array in C Language</h4>
<br />


<hr/>
<div><ul class="pager">
<li class="previous">
<a href="inline-functions.php">&larr; Prev</a>
</li>
<li class="next">
<a href="constructors-and-destructors-in-cpp.php">Next &rarr;</a>
</li>
</ul></div>
<br>

 </div>
 <div class="col-sm-2">
 </div>
 
</body>
</html>
