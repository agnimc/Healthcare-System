<a href="index.php"></a> 
<a href="index.php?page=add-doctor"><b style="color:#CC0000"> Add doctor<b></a>&nbsp; |&nbsp;
<a href="index.php?page=doctor-list"><b style="color:#CC0000"> Doctor list<b></a>&nbsp; |&nbsp;
<a href="index.php?page=add-patient"><b style="color:#CC0000">Add Patient</b></a> &nbsp; |&nbsp;
<a href="index.php?page=patient-list"><b style="color:#CC0000">Patient list</b></a> &nbsp; |&nbsp;
<a href="index.php?page=add-appointment"><b style="color:#CC0000">Add Appointment</b></a>  &nbsp; |&nbsp;
<a href="index.php?page=appointment-list"><b style="color:#CC0000">Appointment list</b></a>